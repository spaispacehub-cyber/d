package vn.ahbots;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public final class AHBots extends JavaPlugin implements TabExecutor {
    private Method apiGetInstance, apiGetAuctionManager, createListing;
    private Object api;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        try {
            Class<?> apiClass = Class.forName("bg.pikz.zelauction.api.ZelAuctionAPI");
            apiGetInstance = apiClass.getMethod("getInstance");
            api = apiGetInstance.invoke(null);
            apiGetAuctionManager = apiClass.getMethod("getAuctionManager");
            Object manager = apiGetAuctionManager.invoke(api);
            createListing = manager.getClass().getMethod("createListing", Player.class, ItemStack.class, double.class);
        } catch (Exception e) {
            getLogger().severe("Could not connect to ZelAuction API: " + e.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        getCommand("ahbot").setExecutor(this);
        getCommand("ahbot").setTabCompleter(this);
        getLogger().info("AHBots enabled. Note: ZelAuction requires a real Player seller.");
    }

    private boolean sell(Player seller, Material material, int amount, double price) {
        try {
            ItemStack item = new ItemStack(material, amount);
            Object manager = apiGetAuctionManager.invoke(api);
            Object result = createListing.invoke(manager, seller, item, price);
            if (result instanceof CompletableFuture<?>) {
                ((CompletableFuture<?>) result).exceptionally(ex -> {
                    getLogger().warning("Listing failed: " + ex.getMessage());
                    return null;
                });
            }
            return true;
        } catch (Exception e) {
            seller.sendMessage("§cAHBots error: " + e.getCause());
            return false;
        }
    }

    @Override
    public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (a.length == 0) {
            s.sendMessage("§e/ahbot sell <player> <material> <amount> <price>");
            return true;
        }
        if (a[0].equalsIgnoreCase("sell") && a.length == 5) {
            Player p = Bukkit.getPlayerExact(a[1]);
            if (p == null) { s.sendMessage("§cPlayer must be online."); return true; }
            Material m = Material.matchMaterial(a[2]);
            if (m == null) { s.sendMessage("§cInvalid material."); return true; }
            try {
                int amount = Integer.parseInt(a[3]);
                double price = Double.parseDouble(a[4]);
                if (amount < 1 || price < 0) throw new NumberFormatException();
                if (sell(p, m, amount, price))
                    s.sendMessage("§aListing submitted for " + p.getName());
            } catch (NumberFormatException ex) {
                s.sendMessage("§cInvalid amount/price.");
            }
            return true;
        }
        s.sendMessage("§e/ahbot sell <player> <material> <amount> <price>");
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender s, Command c, String l, String[] a) {
        if (a.length == 1) return List.of("sell");
        if (a.length == 2) return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        if (a.length == 3) return List.of("DIAMOND", "EMERALD", "OBSIDIAN", "NETHERITE_INGOT");
        return List.of();
    }
}
